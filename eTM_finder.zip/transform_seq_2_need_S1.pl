open IN, "$ARGV[0]";
open OUT, ">$ARGV[1]";
open OUT2, ">$ARGV[2]";
while (<IN>){
	chomp;
	if(/>/){
		$title=$_;
	}
	else{
		$Hash{$title}.=$_;
	}
	
}
	foreach $key (keys %Hash){
   $len=length $Hash{$key};
   if($len > 200){
   	$plus=$Hash{$key};
   	$plus=~tr/ATCG/TAGC/;
   	print OUT "$key\n$plus\n";
  }
  
}
	foreach $key (keys %Hash){
   $len=length $Hash{$key};
   if($len > 200){
   	$newt=reverse $Hash{$key};
   	print OUT2 "$key\n$newt\n";
  }
  
}


	