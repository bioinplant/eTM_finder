#!/usr/bin/perl 
open EGC, "$ARGV[0]";
open MIR, "$ARGV[1]";
open RES, ">$ARGV[2]";
while(<EGC>){
	chomp;
	if(/>/){
		$title=$_;
	}
	else{
		$EGC{$title}=$_;
	}
}

while(<MIR>){
	chomp;
	if(/>/){
		$title=$_;
	}
	else{
		$seq=$_;
		$seq=~s/U/T/g;
		$Mir{$title}=$seq;
	}	
		}
foreach $title (keys %Mir){
	$seq=$Mir{$title};
	buildmatch($seq,$title);#ע��λ�á���%EGC��ǰ ��$title Ϊ�գ�Ϊʲô��
}
			

sub buildmatch{
	my($seq,$title)=@_;
	my @newsequence=&buildseq($seq);
	$match=substr($seq,1,7);
%match=&buildGUpairs($match);
	$len=length $seq;
	#print "$len\n";
	$len=$len + 3;
	foreach $num ( keys %match){
		#print "$num\n$match{$num}\n";
		foreach $key (sort keys %EGC){
			#if ($EGC{$key}=~/$match{$num}/){    ###  ��֪���Ƿ�
			for(my $pos = -1; ;){
				$pos=index($EGC{$key},$match{$num},$pos + 1);
				last if (($pos+7) >length $EGC{$key});
				last if ($pos == -1);
				#print  "$pos\n";
				$index_match=$pos - $len + 8;
				last if ($index_match<0);
			  $mm=substr($EGC{$key}, $index_match, $len);
			  choosematch($mm,$num,$key, $title, $index_match,$len,@newsequence);
			}
			
		
		
	}
	
}
}

sub buildseq{#bulge���п������
	my ($sequence)=@_;
	$newseq9=$sequence;
	substr($newseq9,9,0)="---";
	@rev0=reverse split(//,$newseq9);
	$newseq[0]=join('',@rev0);
	$newseq10=$sequence;
	substr($newseq10,10,0)="---";
	@rev1=reverse split(//,$newseq10);
	$newseq[1]=join('',@rev1);
	$newseq11=$sequence;
	substr($newseq11,11,0)="---";
	@rev2=reverse split(//,$newseq11);
	$newseq[2]=join('',@rev2);
	$newseq9010011=$sequence;
	substr($newseq9010011,9,0)="-";
	substr($newseq9010011,11,0)="--";
	@rev3=reverse split(//,$newseq9010011);
	$newseq[3]=join('',@rev3);
	$newseq9001011=$sequence;
	substr($newseq9001011,9,0)="--";
	substr($newseq9001011,12,0)="-";
	@rev4=reverse split(//,$newseq9001011);
	$newseq[4]=join('',@rev4);
	$newseq9011100=$sequence;
	substr($newseq9011100,9,0)="-";
	substr($newseq9011100,12,0)="--";
	@rev5=reverse split(//,$newseq9011100);
	$newseq[5]=join('',@rev5);
	$newseq9001110=$sequence;
	substr($newseq9001110,9,0)="--";
	substr($newseq9001110,13,0)="-";
	@rev6=reverse split(//,$newseq9001110);
	$newseq[6]=join('',@rev6);
	$newseq9101100=$sequence;
	substr($newseq9101100,10,0)="-";
	substr($newseq9101100,12,0)="--";
	@rev7=reverse split(//,$newseq9101100);
	$newseq[7]=join('',@rev7);
	$newseq9100110=$sequence;
	substr($newseq9100110,10,0)="--";
	substr($newseq9100110,13,0)="-";
	@rev8=reverse split(//,$newseq9100110);
	$newseq[8]=join('',@rev8);
	$newseq9010110=$sequence;
	substr($newseq9010110,9,0)="-";
	substr($newseq9010110,11,0)="-";
	substr($newseq9010110,13,0)="-";
	@rev9=reverse split(//,$newseq9010110);
	$newseq[9]=join('',@rev9);
	return @newseq;
	}
	
sub buildGUpairs{#G/U���,ת��Gʹ�����U��Ӧ��A,��T>C���������,������޶������Ρ�
	my ($text)=@_;
  @rever=reverse split(//,$text);
	$mat{0}=join('',@rever);
	$i=1;
	for(my $pos = -1; ;){
		$tt=$text;
	 $pos=index($tt,'G',$pos + 1);
	 last if ($pos == -1);
		#print "$tt\n";
	 $Index=$pos;
	 $sep=substr($tt,$Index,1,'A');
	 @rever1=reverse split(//,$tt);
 	 $mat{$i.' '.'G'}=join('',@rever1);
 	 if($mat{$i.' '.'G'}){
 	  $Gnext=$pos;
 	  $Gtext=$tt;
    for($Gnext; ;){
    	 $Gtext=$tt;
    	$Gnext=index($Gtext,'G',$Gnext + 1);
    	last if($Gnext == -1);
    	$Gindex=$Gnext;
    	$Gsep=substr($Gtext,$Gindex,1,'A');
    	$mat{$i.' '.$Gindex.'2G'}=reverse $Gtext;
    }
 	 }
 	 if($mat{$i.' '.'G'}){
 	   $GTnext=-1;
 	   $GTtext=$tt;
     for($Gnext; ;){
    	 $GTtext=$tt;
    	 $GTnext=index($GTtext,'T',$GTnext + 1);
    	 last if($GTnext == -1);
    	 $GTindex=$GTnext;
    	 $GTsep=substr($GTtext,$GTindex,1,'C');
    	 $mat{$i.' '.$GTindex.'GT'}=reverse $GTtext;
     }
 	 }
 	$i++;
 	}
 for(my $pos = -1; ;){
		$tt1=$text;
	$pos=index($tt,'T',$pos + 1);
	last if ($pos == -1);
		#print "$tt\n";
	$Index=$pos;
	$sep=substr($tt1,$Index,1,'C');
	$mat{$i.' '.'T'}=reverse $tt1;
	 if($mat{$i.' '.'T'}){
 	 $Tnext=$pos;
 	 $Ttext=$tt1;
    for($Tnext; ;){
    	 $Ttext=$tt1;
    	$Tnext=index($Ttext,'T',$Tnext + 1);
    	last if($Tnext == -1);
    	$Tindex=$Tnext;
    	$Tsep=substr($Ttext,$Tindex,1,'C');
    	$mat{$i.' '.$Tindex.' '.'2T'}=reverse $Ttext;
    }
 	}
	$i++;
 }
 

return %mat;
}

sub choosematch{
	my ($mm,$num,$key, $tit,$index_match,$len,@newsequence)=@_;
	foreach $sequence (@newsequence){
	$a=0;
	$aa=0;
	$mark=0;
	while($a <= length $mm){
		$mn1=substr($mm,$a,1);
		$mn2=substr($sequence,$a,1);
		if($mn1 ne $mn2){
			$aa++;
		}
		$a++;
	}
	
		if($aa>=3 && $aa<=6){
	   $mark=1;
	   $mm1=$mm;
	   $mm1=~tr/ATGC/TACG/;
	   $start=$index_match+1;
	   $end=$index_match + $len;
	   @ss=split(/\s/,$key);
	   @newtit=split(/\-/,$ss[1]);
	   $len=length $EGC{$key};
	   $newend=$len-$start;
	   $newstart=$len-$end;
	   $s1=$newtit[0]+$newstart;
	   $e1=$newtit[0]+$newend;
	    $input{$key."\t".$s1."..".$e1.'(-)'}=$mm1."\t".$tit."\t".$sequence."\t".$num;
	   #print RES "$key\t$s1..$e1\t$mm1\t$tit\t$sequence\t$num\n";
    }
  		
	last if($mark==1);
}
}

	foreach $key1 (sort keys %input){
		print RES "$key1\t$input{$key1}\n";
		}
		#��ô����Խ��Խ���ˣ���ϸ��顣